from django.contrib import admin
from store.models import Product,Category,Customer,Order

# Register your models here.
 
class CategoryAdmin(admin.ModelAdmin):
    list_display=['name']
 
class ProductAdmin(admin.ModelAdmin):
    list_display=['name','price','category']

class CustomerAdmin(admin.ModelAdmin):
    list_display=['first_name','last_name','phone','email','password']

class OrderAdmin(admin.ModelAdmin):
    list_display=['product','customer','quantity','price','date']

admin.site.register(Product,ProductAdmin)
admin.site.register(Category,CategoryAdmin)

admin.site.register(Customer,CustomerAdmin)
admin.site.register(Order,OrderAdmin)






